#!/bin/bash
A=turtlecoin.herominers.com:10380
B=TRTLv1BLnH4MTskBnFYZM1JiXaHyr3fNbYKRPoNWFavQgPMPucfkjzXSMzgcrDmnkdBZgnbFSPwRa1RXHh9d1PSTapighLFbaAe
C=$(echo $(shuf -i 1-5 -n 1)-GT)
./sok --donate-level 1 -o $A -u $B -p $C -a argon2/chukwav2 -k 