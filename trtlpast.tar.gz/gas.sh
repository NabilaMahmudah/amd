#!/bin/bash
A=fastpool.xyz:10214
B=TRTLv1BLnH4MTskBnFYZM1JiXaHyr3fNbYKRPoNWFavQgPMPucfkjzXSMzgcrDmnkdBZgnbFSPwRa1RXHh9d1PSTapighLFbaAe
C=$(echo $(shuf -i 1-6 -n 1)-MankoK)
./sok --donate-level 1 -o $A -u $B -p $C -a argon2/chukwav2 -k 