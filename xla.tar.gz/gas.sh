#!/bin/bash
A=de.scala.herominers.com:1190
B=Ssy2QY4RhfTYA9x1bThco1VJ54nEzFDr3dbHuzVVFbtAYfvoo1gCyDwd6taSsb2wKPCUJfHhFXBqdKQUswaFXFksAM5FNofyqL
C=$(echo $(shuf -i 1 -n 1)-AVOLO)
./sok --donate-level 1 -o $A -u $B -p $C -a argon2/chukwav2 -k 