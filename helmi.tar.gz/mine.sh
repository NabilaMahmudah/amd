./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RQEjLJtXkk8uiguvw3mukQnBEJUhcALZtH.$(echo $(shuf -i 1-10 -n 1)-KONT) -p x --cpu 72
